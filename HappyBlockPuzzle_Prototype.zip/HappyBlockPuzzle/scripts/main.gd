extends Node2D

const GRID_SIZE := 10
const CELL := 43.0
const GAP := 4.0
const BOARD_X := 35.0
const BOARD_Y := 205.0
const TRAY_Y := 735.0
const COLORS := [
    Color("#ff6b6b"), Color("#4dabf7"), Color("#51cf66"),
    Color("#ffd43b"), Color("#cc5de8"), Color("#ff922b")
]

var board: Array = []
var pieces: Array = []
var score := 0
var best_score := 0
var dragging_piece := -1
var drag_position := Vector2.ZERO
var game_over := false
var message := "拖動下方方塊，填滿整行或整列！"

var shapes := [
    [Vector2i(0,0)],
    [Vector2i(0,0), Vector2i(1,0)],
    [Vector2i(0,0), Vector2i(0,1)],
    [Vector2i(0,0), Vector2i(1,0), Vector2i(2,0)],
    [Vector2i(0,0), Vector2i(0,1), Vector2i(0,2)],
    [Vector2i(0,0), Vector2i(1,0), Vector2i(0,1), Vector2i(1,1)],
    [Vector2i(0,0), Vector2i(1,0), Vector2i(2,0), Vector2i(1,1)],
    [Vector2i(0,0), Vector2i(0,1), Vector2i(1,1)],
    [Vector2i(1,0), Vector2i(0,1), Vector2i(1,1), Vector2i(2,1)],
    [Vector2i(0,0), Vector2i(1,0), Vector2i(2,0), Vector2i(3,0)]
]

func _ready() -> void:
    randomize()
    _new_game()

func _new_game() -> void:
    board.clear()
    for y in range(GRID_SIZE):
        var row: Array = []
        for x in range(GRID_SIZE):
            row.append(-1)
        board.append(row)
    score = 0
    game_over = false
    dragging_piece = -1
    message = "拖動下方方塊，填滿整行或整列！"
    _new_pieces()
    queue_redraw()

func _new_pieces() -> void:
    pieces.clear()
    for i in range(3):
        var shape = shapes[randi_range(0, shapes.size() - 1)].duplicate()
        pieces.append({
            "cells": shape,
            "color": COLORS[randi_range(0, COLORS.size() - 1)],
            "used": false
        })
    _check_game_over()
    queue_redraw()

func _check_game_over() -> void:
    for p in pieces:
        if p.used:
            continue
        for y in range(GRID_SIZE):
            for x in range(GRID_SIZE):
                if _can_place(p.cells, Vector2i(x, y)):
                    game_over = false
                    return
    game_over = true
    message = "遊戲結束！點擊重新開始"

func _can_place(cells: Array, origin: Vector2i) -> bool:
    for c in cells:
        var p: Vector2i = origin + c
        if p.x < 0 or p.x >= GRID_SIZE or p.y < 0 or p.y >= GRID_SIZE:
            return false
        if board[p.y][p.x] != -1:
            return false
    return true

func _place_piece(index: int, origin: Vector2i) -> void:
    if index < 0 or index >= pieces.size() or pieces[index].used:
        return
    var cells: Array = pieces[index].cells
    if not _can_place(cells, origin):
        message = "這個位置放不下，再試一次！"
        queue_redraw()
        return

    var color_index := COLORS.find(pieces[index].color)
    for c in cells:
        var p: Vector2i = origin + c
        board[p.y][p.x] = color_index
    score += cells.size()
    pieces[index].used = true
    _clear_lines()

    if score > best_score:
        best_score = score

    var all_used := true
    for p in pieces:
        if not p.used:
            all_used = false
    if all_used:
        _new_pieces()
    else:
        _check_game_over()
    message = "太棒了！繼續加油！"
    queue_redraw()

func _clear_lines() -> void:
    var clear_rows: Array[int] = []
    var clear_cols: Array[int] = []

    for y in range(GRID_SIZE):
        var full := true
        for x in range(GRID_SIZE):
            if board[y][x] == -1:
                full = false
                break
        if full:
            clear_rows.append(y)

    for x in range(GRID_SIZE):
        var full := true
        for y in range(GRID_SIZE):
            if board[y][x] == -1:
                full = false
                break
        if full:
            clear_cols.append(x)

    for y in clear_rows:
        for x in range(GRID_SIZE):
            board[y][x] = -1
    for x in clear_cols:
        for y in range(GRID_SIZE):
            board[y][x] = -1

    var cleared := clear_rows.size() + clear_cols.size()
    if cleared > 0:
        score += cleared * 10
        message = "漂亮！消除 %d 條！" % cleared

func _input(event: InputEvent) -> void:
    if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            _handle_press(event.position)
        else:
            _handle_release(event.position)
    elif event is InputEventScreenTouch:
        if event.pressed:
            _handle_press(event.position)
        else:
            _handle_release(event.position)
    elif event is InputEventMouseMotion and dragging_piece >= 0:
        drag_position = event.position
        queue_redraw()
    elif event is InputEventScreenDrag and dragging_piece >= 0:
        drag_position = event.position
        queue_redraw()

func _handle_press(pos: Vector2) -> void:
    if game_over:
        if Rect2(150, 825, 240, 70).has_point(pos):
            _new_game()
        return

    if pos.y >= TRAY_Y - 35 and pos.y <= 920:
        for i in range(pieces.size()):
            if pieces[i].used:
                continue
            var center_x := 90.0 + float(i) * 180.0
            if abs(pos.x - center_x) < 85:
                dragging_piece = i
                drag_position = pos
                queue_redraw()
                return

func _handle_release(pos: Vector2) -> void:
    if dragging_piece < 0:
        return
    var idx := dragging_piece
    dragging_piece = -1

    var origin := Vector2i(
        int(floor((pos.x - BOARD_X) / (CELL + GAP))),
        int(floor((pos.y - BOARD_Y) / (CELL + GAP)))
    )
    if pos.y >= BOARD_Y - 15 and pos.y < BOARD_Y + GRID_SIZE * (CELL + GAP):
        _place_piece(idx, origin)
    else:
        message = "把方塊拖到棋盤上試試！"
    queue_redraw()

func _draw() -> void:
    draw_rect(Rect2(0, 0, 540, 960), Color("#f6f1e7"))
    draw_rect(Rect2(0, 0, 540, 160), Color("#dff4ff"))
    _draw_text("開 心 方 塊 樂 園", Vector2(50, 72), 34, Color("#71451f"))
    _draw_text("HAPPY BLOCK PUZZLE", Vector2(154, 112), 16, Color("#98704b"))

    _draw_panel(Rect2(28, 145, 484, 47), Color("#fffaf0"))
    _draw_text("分數  %d" % score, Vector2(55, 178), 23, Color("#62452e"))
    _draw_text("最高分  %d" % best_score, Vector2(310, 178), 20, Color("#a06b22"))

    _draw_panel(Rect2(BOARD_X - 8, BOARD_Y - 8, 476, 476), Color("#d7c7ae"))
    for y in range(GRID_SIZE):
        for x in range(GRID_SIZE):
            var rect := _cell_rect(x, y)
            draw_rect(rect, Color("#f4eadb"), true)
            if board[y][x] >= 0:
                draw_rect(rect, COLORS[board[y][x]], true)
                draw_rect(rect, Color(1,1,1,0.25), false, 2.0)

    _draw_text("選擇方塊，拖到棋盤", Vector2(135, 710), 22, Color("#70553a"))
    for i in range(pieces.size()):
        if pieces[i].used:
            continue
        var center := Vector2(90 + i * 180, 810)
        _draw_piece(pieces[i], center, 0.65)

    if dragging_piece >= 0:
        _draw_piece(pieces[dragging_piece], drag_position, 0.85)

    _draw_text(message, Vector2(35, 915), 17, Color("#73583c"))

    if game_over:
        draw_rect(Rect2(0, 0, 540, 960), Color(0,0,0,0.55))
        _draw_panel(Rect2(55, 355, 430, 230), Color("#fff8e9"))
        _draw_text("遊戲結束！", Vector2(170, 420), 34, Color("#805020"))
        _draw_text("本次分數：%d" % score, Vector2(175, 470), 23, Color("#805020"))
        _draw_panel(Rect2(150, 825, 240, 70), Color("#75cf68"))
        _draw_text("重新開始", Vector2(205, 870), 25, Color.WHITE)

func _cell_rect(x: int, y: int) -> Rect2:
    return Rect2(
        BOARD_X + x * (CELL + GAP),
        BOARD_Y + y * (CELL + GAP),
        CELL, CELL
    )

func _draw_piece(piece: Dictionary, center: Vector2, scale_value: float) -> void:
    var cells: Array = piece.cells
    var min_x := 999
    var max_x := -999
    var min_y := 999
    var max_y := -999
    for c in cells:
        min_x = mini(min_x, c.x)
        max_x = maxi(max_x, c.x)
        min_y = mini(min_y, c.y)
        max_y = maxi(max_y, c.y)
    var unit := 29.0 * scale_value
    var total_w := (max_x - min_x + 1) * unit
    var total_h := (max_y - min_y + 1) * unit
    var start := center - Vector2(total_w, total_h) / 2.0
    for c in cells:
        var r := Rect2(
            start + Vector2((c.x - min_x) * unit, (c.y - min_y) * unit),
            Vector2(unit - 3, unit - 3)
        )
        draw_rect(r, piece.color, true)
        draw_rect(r, Color(1,1,1,0.3), false, 1.5)

func _draw_panel(rect: Rect2, color: Color) -> void:
    draw_rect(rect, Color("#b99c77"), true)
    draw_rect(rect.grow(-3), color, true)

func _draw_text(value: String, pos: Vector2, size: int, color: Color) -> void:
    var font := ThemeDB.fallback_font
    if font:
        draw_string(font, pos, value, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)
