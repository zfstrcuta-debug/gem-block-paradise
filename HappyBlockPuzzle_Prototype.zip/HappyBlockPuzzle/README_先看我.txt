# 开心方块乐园 Happy Block Puzzle（原型版）

这是一个 Godot 4.x 的 2D 方块拼图入门项目。

## 目前包含
- 10×10 棋盘
- 三个随机方块
- 鼠标拖动放置（也支持触控输入）
- 满行/满列消除
- 分数和最高分（目前最高分只保存在本次运行内）
- 游戏结束与重新开始

## 如何打开
1. 从 https://godotengine.org/download/windows/ 下载 Windows x86_64 Standard 版本。
2. 解压 Godot。
3. 打开 Godot，点击「Import」。
4. 选择本文件夹中的 `project.godot`。
5. 导入后打开项目，按右上角 ▶ 运行。

## 操作
在窗口底部点住一个方块并拖到棋盘格子上，松开鼠标即可放置。
手机触控输入也已加入，但尚未完成 Android/iOS 导出设置。

## 重要说明
这是核心玩法原型，不是可直接上架的商业成品。
目前尚未加入广告 SDK、内购、隐私政策、云端存档、完整美术资源、音效、每日挑战或商店。
iOS 正式导出需要 macOS 与 Xcode；Windows 可先完成开发与 Android 测试。
